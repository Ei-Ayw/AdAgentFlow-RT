"""Runtime strategy adapters."""
