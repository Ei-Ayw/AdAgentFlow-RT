"""Benchmark adapters."""
